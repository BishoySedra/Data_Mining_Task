# Data_Mining_Task
ECLAT Algorithm Implementation.
